package com.gardinsoft.campus.ms.respuestas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusMsRespuestasApplicationTests {

	@Test
	void contextLoads() {
	}

}
