package com.gardinsoft.campus.ms.examenes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
@EntityScan({"com.gardinsoft.campus.ms.commons.entitys"})
public class CampusMsExamenesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusMsExamenesApplication.class, args);
	}

}
