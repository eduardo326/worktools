package com.gardinsoft.campus.ms.examenes.models.repository;

import org.springframework.data.repository.CrudRepository;

import com.gardinsoft.campus.ms.commons.entitys.Asignatura;

public interface AsignaturaRepository extends CrudRepository<Asignatura, Long>{

}
