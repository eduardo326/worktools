package com.gardinsoft.campus.ms.examenes.services;

import java.util.List;

import com.gardinsoft.campus.ms.commons.entitys.Asignatura;
import com.gardinsoft.campus.ms.commons.entitys.Examen;
import com.gardinsoft.campus.ms.commons.services.CommonService;

public interface ExamenService extends CommonService<Examen>{
	
	public List<Examen> findByNombre(String term);
	
	public List<Asignatura> findAllAsignaturas();
	
	public Iterable<Long> findExamenesIdsConRespuestasByPreguntaIds(Iterable<Long> preguntaIds);

}
