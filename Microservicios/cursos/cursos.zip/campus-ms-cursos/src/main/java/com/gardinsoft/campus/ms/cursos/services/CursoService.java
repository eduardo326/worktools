package com.gardinsoft.campus.ms.cursos.services;

import com.gardinsoft.campus.ms.commons.entitys.Alumno;
import com.gardinsoft.campus.ms.commons.services.CommonService;
import com.gardinsoft.campus.ms.cursos.models.entity.Curso;

public interface CursoService extends CommonService<Curso> {
	public Curso findCursoByAlumnnoId(Long id);
	
	public Iterable<Long> obtenerExamenesIdsConRespuestasAlumno(Long alumnoId);
	
	public Iterable<Alumno> obtenerAlumnosPorCurso(Iterable<Long> ids);
	
	public void eliminarCursoAlumnoPorId(Long id);
}
