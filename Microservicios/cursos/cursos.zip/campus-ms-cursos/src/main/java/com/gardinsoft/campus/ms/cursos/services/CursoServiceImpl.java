package com.gardinsoft.campus.ms.cursos.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gardinsoft.campus.ms.commons.entitys.Alumno;
import com.gardinsoft.campus.ms.commons.services.CommonServiceImpl;
import com.gardinsoft.campus.ms.cursos.clients.AlumnoFeignClient;
import com.gardinsoft.campus.ms.cursos.clients.RespuestaFeignClient;
import com.gardinsoft.campus.ms.cursos.models.entity.Curso;
import com.gardinsoft.campus.ms.cursos.models.repository.CursoRepository;

@Service
public class CursoServiceImpl extends CommonServiceImpl<Curso, CursoRepository> implements CursoService{
	
	@Autowired
	private RespuestaFeignClient client;
	
	@Autowired
	private AlumnoFeignClient clientAlumno;

	@Override
	@Transactional(readOnly = true)
	public Curso findCursoByAlumnnoId(Long id) {
		return repository.findCursoByAlumnnoId(id);
	}

	@Override
	public Iterable<Long> obtenerExamenesIdsConRespuestasAlumno(Long alumnoId) {
		// TODO Auto-generated method stub
		return client.obtenerExamenesIdsConRespuestasAlumno(alumnoId);
	}

	@Override
	public Iterable<Alumno> obtenerAlumnosPorCurso(Iterable<Long> ids) {
		// TODO Auto-generated method stub
		return clientAlumno.obtenerAlumnosPorCurso(ids);
	}
	
	
	@Override
	@Transactional
	public void eliminarCursoAlumnoPorId(Long id) {
		// TODO Auto-generated method stub
		repository.eliminarCursoAlumnoPorId(id);
	}
	
}
