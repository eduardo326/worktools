package com.gardinsoft.campus.ms.zuul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

@EnableZuulProxy
@EnableEurekaClient
@SpringBootApplication
public class CampusMsZuulApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusMsZuulApplication.class, args);
	}

}
