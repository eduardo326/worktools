package com.gardinsoft.campus.ms.zuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusMsZuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
