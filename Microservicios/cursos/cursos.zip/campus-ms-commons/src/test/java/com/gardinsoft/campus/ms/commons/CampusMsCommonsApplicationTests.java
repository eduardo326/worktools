package com.gardinsoft.campus.ms.commons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusMsCommonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
