package com.gardinsoft.campus.ms.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusMsUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
