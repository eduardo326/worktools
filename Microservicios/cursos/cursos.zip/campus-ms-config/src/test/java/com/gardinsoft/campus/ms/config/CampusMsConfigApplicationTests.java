package com.gardinsoft.campus.ms.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusMsConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
