
-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-08-2021 a las 00:38:14
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `campus_ms_examenes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignaturas`
--

CREATE TABLE `asignaturas` (
  `id` bigint(20) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `asignatura_padre_id` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `asignaturas`
--

INSERT INTO `asignaturas` (`id`, `nombre`, `asignatura_padre_id`) VALUES
(1, 'Matemáticas', NULL),
(2, 'Lenguaje', NULL),
(3, 'Inglés', NULL),
(4, 'Ciencias Naturales', NULL),
(5, 'Ciencias Sociales y Historia', NULL),
(6, 'Música', NULL),
(7, 'Artes', NULL),
(8, 'Algebra', 1),
(9, 'Aritmética', 1),
(10, 'Trigonometría', 1),
(11, 'Lectura y comprensión', 2),
(12, 'Verbos', 2),
(13, 'Gramática', 2),
(14, 'Inglés', 3),
(15, 'Gramática', 3),
(16, 'Verbos', 3),
(17, 'Ciencias Naturales', 4),
(18, 'Biología', 4),
(19, 'Física', 4),
(20, 'Quimica', 4),
(21, 'Historia', 5),
(22, 'Ciencias Sociales', 5),
(23, 'Filosofía', 5),
(24, 'Música', 6),
(25, 'Artes', 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos`
--

CREATE TABLE `cursos` (
  `id` bigint(20) NOT NULL,
  `create_at` datetime DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cursos`
--

INSERT INTO `cursos` (`id`, `create_at`, `nombre`) VALUES
(1, '2021-04-24 18:40:27', '1 primaria'),
(2, '2021-04-24 18:40:31', '2 primaria'),
(3, '2021-04-24 18:41:04', '3 primaria'),
(4, '2021-04-24 18:41:08', '4 primaria'),
(5, '2021-04-24 18:41:14', '5 primaria'),
(7, '2021-06-14 21:34:13', '1 Secundaria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos_alumnos`
--

CREATE TABLE `cursos_alumnos` (
  `id` bigint(20) NOT NULL,
  `alumno_id` bigint(20) DEFAULT NULL,
  `curso_id` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cursos_alumnos`
--

INSERT INTO `cursos_alumnos` (`id`, `alumno_id`, `curso_id`) VALUES
(3, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursos_examenes`
--

CREATE TABLE `cursos_examenes` (
  `curso_id` bigint(20) NOT NULL,
  `examenes_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cursos_examenes`
--

INSERT INTO `cursos_examenes` (`curso_id`, `examenes_id`) VALUES
(2, 2),
(2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examenes`
--

CREATE TABLE `examenes` (
  `id` bigint(20) NOT NULL,
  `create_at` datetime DEFAULT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `asignatura_hija_id` bigint(20) NOT NULL,
  `asignatura_padre_id` bigint(20) NOT NULL,
  `asignatura_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `examenes`
--

INSERT INTO `examenes` (`id`, `create_at`, `nombre`, `asignatura_hija_id`, `asignatura_padre_id`, `asignatura_id`) VALUES
(1, '2021-04-25 14:06:21', 'Examen de Historia', 21, 5, 0),
(2, '2021-04-25 14:09:07', 'Examen de Historia 2', 21, 5, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `id` bigint(20) NOT NULL,
  `texto` varchar(255) DEFAULT NULL,
  `examen_id` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`id`, `texto`, `examen_id`) VALUES
(1, 'Pegunta 1 de ejemplo', 1),
(2, 'Pegunta 2', 1),
(3, 'Pegunta 3', 1),
(5, 'Pegunta 1', 2),
(6, 'Pegunta 2', 2),
(7, 'Pegunta 3', 2),
(8, 'Pegunta 4', 2),
(16, 'Pegunta 5', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asignaturas`
--
ALTER TABLE `asignaturas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKri6a2799lhv6nl5ahhp1go8pb` (`asignatura_padre_id`);

--
-- Indices de la tabla `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cursos_alumnos`
--
ALTER TABLE `cursos_alumnos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_pb88irw9u3c0h2lsf3q1kluv9` (`alumno_id`),
  ADD KEY `FKb90xg2w8jai6w555c3erim0cv` (`curso_id`);

--
-- Indices de la tabla `cursos_examenes`
--
ALTER TABLE `cursos_examenes`
  ADD KEY `FK6ags9h8g0q074pch8ckfy8nw5` (`examenes_id`),
  ADD KEY `FKbj3nwplxm8hswqcbt0tmrqagj` (`curso_id`);

--
-- Indices de la tabla `examenes`
--
ALTER TABLE `examenes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK8c89lnsrfhtuvaho2asigrcaw` (`asignatura_hija_id`),
  ADD KEY `FKbrfkorjspukivcec7dsn26dv8` (`asignatura_padre_id`),
  ADD KEY `FK6ti4mhut3mays6044rt8syqd8` (`asignatura_id`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK9hlw51x7hfqs1tv3sviwqycqi` (`examen_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asignaturas`
--
ALTER TABLE `asignaturas`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `cursos_alumnos`
--
ALTER TABLE `cursos_alumnos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `examenes`
--
ALTER TABLE `examenes`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
